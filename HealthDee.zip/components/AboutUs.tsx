import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Heart, Users, Award, Globe, Shield, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutUs() {
  const teamMembers = [
    {
      name: "Dr. Alexandra Morgan",
      role: "Chief Medical Officer",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&h=300&fit=crop&face",
      bio: "Board-certified physician with 20+ years in healthcare innovation and digital health solutions."
    },
    {
      name: "David Kumar",
      role: "CEO & Founder",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&face",
      bio: "Healthcare technology entrepreneur passionate about making quality healthcare accessible to everyone."
    },
    {
      name: "Sarah Chen",
      role: "Head of Technology",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&face",
      bio: "Former Silicon Valley engineer specializing in AI and machine learning applications in healthcare."
    },
    {
      name: "Dr. Robert Martinez",
      role: "Clinical Director",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300&h=300&fit=crop&face",
      bio: "Practicing physician and healthcare quality improvement expert with extensive clinical experience."
    }
  ];

  const values = [
    {
      icon: Heart,
      title: "Patient First",
      description: "Every decision we make prioritizes patient well-being and healthcare outcomes."
    },
    {
      icon: Shield,
      title: "Trust & Security",
      description: "We maintain the highest standards of data privacy and security for all users."
    },
    {
      icon: Users,
      title: "Accessibility",
      description: "Making quality healthcare accessible to everyone, regardless of their background."
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Partnering only with verified, licensed healthcare professionals and institutions."
    },
    {
      icon: Globe,
      title: "Innovation",
      description: "Leveraging cutting-edge technology to transform the healthcare experience."
    },
    {
      icon: Clock,
      title: "24/7 Support",
      description: "Round-the-clock assistance to ensure you get the care you need, when you need it."
    }
  ];

  const stats = [
    { number: "2018", label: "Founded" },
    { number: "500+", label: "Partner Hospitals" },
    { number: "10,000+", label: "Verified Doctors" },
    { number: "1M+", label: "Patients Served" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950/20 dark:to-indigo-950/20 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            <Heart className="w-3 h-3 mr-1" />
            About HealthCare+
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Transforming Healthcare Through Technology
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            We're on a mission to make quality healthcare accessible, affordable, and convenient 
            for everyone. Our platform connects patients with the best healthcare providers while 
            leveraging AI to provide personalized health insights.
          </p>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-6">Our Vision</h2>
              <p className="text-lg text-muted-foreground mb-6">
                To create a world where everyone has access to quality healthcare, regardless of 
                their location, economic status, or background. We envision a future where 
                technology bridges the gap between patients and healthcare providers.
              </p>
              <h2 className="text-3xl font-bold text-foreground mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground">
                To democratize healthcare by providing a comprehensive platform that connects 
                patients with verified healthcare providers, offers AI-powered health assistance, 
                and ensures transparent, quality care for all.
              </p>
            </div>
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=600&h=400&fit=crop"
                alt="Healthcare technology"
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Values</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{value.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-3xl lg:text-4xl font-bold mb-2">{stat.number}</div>
                <div className="text-primary-foreground/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Meet Our Team</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Experienced healthcare professionals and technology experts working together
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-24 h-24 mx-auto rounded-full overflow-hidden mb-4">
                    <ImageWithFallback
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-lg">{member.name}</CardTitle>
                  <CardDescription className="font-medium text-primary">{member.role}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Join Us in Transforming Healthcare
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Whether you're a patient seeking quality care or a healthcare provider wanting to reach more patients
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Badge variant="outline" className="text-sm py-2 px-4">
              <Heart className="w-4 h-4 mr-2" />
              Trusted by 1M+ patients
            </Badge>
            <Badge variant="outline" className="text-sm py-2 px-4">
              <Award className="w-4 h-4 mr-2" />
              10,000+ verified doctors
            </Badge>
          </div>
        </div>
      </section>
    </div>
  );
}