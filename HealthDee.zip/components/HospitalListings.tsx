import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Star, MapPin, Phone, Clock, Users } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Hospital {
  id: number;
  name: string;
  location: string;
  specialty: string;
  rating: number;
  reviewCount: number;
  image: string;
  phone: string;
  description: string;
  facilities: string[];
  established: string;
}

export function HospitalListings() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');

  const hospitals: Hospital[] = [
    {
      id: 1,
      name: "City General Hospital",
      location: "Downtown, NY",
      specialty: "General Medicine",
      rating: 4.8,
      reviewCount: 523,
      image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400&h=300&fit=crop",
      phone: "+1 (555) 123-4567",
      description: "Leading healthcare facility with state-of-the-art equipment and experienced medical professionals.",
      facilities: ["Emergency Care", "ICU", "Surgery", "Diagnostics"],
      established: "1985"
    },
    {
      id: 2,
      name: "Heart & Vascular Institute",
      location: "Midtown, NY",
      specialty: "Cardiology",
      rating: 4.9,
      reviewCount: 341,
      image: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=400&h=300&fit=crop",
      phone: "+1 (555) 987-6543",
      description: "Specialized cardiac care center with advanced interventional procedures and rehabilitation programs.",
      facilities: ["Cardiac Surgery", "Cath Lab", "Rehabilitation", "Monitoring"],
      established: "1995"
    },
    {
      id: 3,
      name: "Women's Health Center",
      location: "Uptown, NY",
      specialty: "Gynecology",
      rating: 4.7,
      reviewCount: 287,
      image: "https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=400&h=300&fit=crop",
      phone: "+1 (555) 456-7890",
      description: "Comprehensive women's healthcare services including obstetrics, gynecology, and fertility treatments.",
      facilities: ["Maternity Ward", "NICU", "Fertility Center", "Women's Imaging"],
      established: "2001"
    },
    {
      id: 4,
      name: "Children's Medical Center",
      location: "Suburbs, NY",
      specialty: "Pediatrics",
      rating: 4.6,
      reviewCount: 412,
      image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400&h=300&fit=crop",
      phone: "+1 (555) 321-9876",
      description: "Dedicated pediatric hospital providing specialized care for children and adolescents.",
      facilities: ["Pediatric ICU", "Emergency", "Surgery", "Therapy"],
      established: "1990"
    }
  ];

  const specialties = [
    'General Medicine',
    'Cardiology',
    'Gynecology',
    'Pediatrics',
    'Orthopedics',
    'Neurology'
  ];

  const locations = [
    'Downtown, NY',
    'Midtown, NY',
    'Uptown, NY',
    'Suburbs, NY'
  ];

  const filteredHospitals = hospitals.filter(hospital => {
    const matchesSearch = hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         hospital.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = selectedSpecialty === 'all' || hospital.specialty === selectedSpecialty;
    const matchesLocation = selectedLocation === 'all' || hospital.location === selectedLocation;
    
    return matchesSearch && matchesSpecialty && matchesLocation;
  });

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Hospitals & Clinics</h1>
          <p className="text-muted-foreground">Find the best healthcare facilities in your area</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-card rounded-lg border border-border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Search</label>
              <Input
                type="text"
                placeholder="Search hospitals or locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Specialty</label>
              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger>
                  <SelectValue placeholder="Select specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {specialties.map(specialty => (
                    <SelectItem key={specialty} value={specialty}>{specialty}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Location</label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  {locations.map(location => (
                    <SelectItem key={location} value={location}>{location}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredHospitals.map(hospital => (
            <Card key={hospital.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video relative">
                <ImageWithFallback
                  src={hospital.image}
                  alt={hospital.name}
                  className="w-full h-full object-cover"
                />
                <Badge className="absolute top-4 left-4 bg-background/90 text-foreground">
                  {hospital.specialty}
                </Badge>
              </div>
              
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{hospital.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1 mt-1">
                      <MapPin className="w-4 h-4" />
                      {hospital.location}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">{hospital.rating}</span>
                    <span className="text-muted-foreground text-sm">({hospital.reviewCount})</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{hospital.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {hospital.facilities.map((facility, index) => (
                    <Badge key={index} variant="secondary">{facility}</Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {hospital.phone}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    Est. {hospital.established}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button className="flex-1">View Details</Button>
                  <Button variant="outline" className="flex-1">Write Review</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredHospitals.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No hospitals found matching your criteria.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => {
                setSearchTerm('');
                setSelectedSpecialty('all');
                setSelectedLocation('all');
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}